<?php
header("Access-Control-Allow-Origin: *");
$aq = $_POST["aq"];
$url = "Q4.json" ;
$xml = file_get_contents($url, false);
$xml = json_decode($xml);
print ("<p>行政區:$aq</p>");
print ("<table><tr><td>行政區</td><td>負責單位</td><td>地址</td></tr>");
foreach ($xml->result->results as $key )
{
    $name = $key->{"APP_NAME"};
	$add = $key->{"ADDR"};
    $value = $key->{"C_NAME"};
	if($aq == $value){
		print ("<tr><td>$value</td><td>$name</td><td>$add</td></tr>");
	}
}
print ("</table>");
?>