<?php
$data = file_get_contents("debug.csv");
print $data;
?>

