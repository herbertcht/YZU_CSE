<?php
header("Access-Control-Allow-Origin: *");
$url = "Q3.json";
$data = file_get_contents($url);
print $data;
?>

 
