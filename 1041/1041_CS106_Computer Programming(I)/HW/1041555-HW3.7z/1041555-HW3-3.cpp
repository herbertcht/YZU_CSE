// UVa Online Judge: 256
#include <iostream>
using namespace std;

int main()
{
    int name,x,y;
    
    cout << "Enter the number of digits (taken from 2, 4, 6, 8): ";
    
    cin >> name;
    
    if ( name == 2 )
    {
        for ( x = 0 ; x <= 9 ; ++x)
        for ( y = 0 ; y <= 9 ; ++y)
            if ( ( x + y ) * ( x + y ) == ( x * 10 + y)) 
            cout << x << y << endl;
    }
   
    if ( name == 4 )
    {
    	cout << "0000" << endl << "0001" << endl;	//發現規律會有0和1
        for ( x = 1 ; x <= 97 ; ++x)						//x是頭 y是尾
        for ( y = 1 ; y <= 99 ; ++y)
            if ( ( x + y ) * ( x + y ) == ( x * 100 + y))	//(x + y)^2 = x*100 + y
            {
            	
            	cout << x << y << endl;

            }
    	cout << "9801" << endl;						//發現規律，尾是這樣
            
    }
    
    if ( name == 6 )
    {
    	cout << "000000" << endl << "000001" << endl;
        for ( x = 0001 ; x <= 997 ; ++x)
        for ( y = 0001 ; y <= 999 ; ++y)
            if ( ( x + y ) * ( x + y ) == ( x * 1000 + y))
            {
                if ( x == 88)					//計算時特別數字
            	cout << "0" <<  x << y << endl;
            	else
            	cout << x << y << endl;
            }
        cout << "998001" << endl;
    }
   
    if ( name == 8 )
    {
        cout << "00000000" << endl << "00000001" << endl;
        for ( x = 0001 ; x <= 9997 ; ++x)
        for ( y = 0001 ; y <= 9999 ; ++y)
            if ( ( x + y ) * ( x + y ) == ( x * 10000 + y)) 
            {
                if( x == 494 || x == 744)
                cout << "0" << x << y << endl;
                else
                cout << x << y << endl;
            }
                

            cout << "98000001" << endl;
    }
}
