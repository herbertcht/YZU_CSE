//finds the two largest values among several integers.
//Assume that the first integer read specifies the number of values remaining to be entered. 
#include <iostream>
using namespace std;
int main()
{
	int i, largest, secondLargest, temp;
	cout << "Enter the number of integers to be processed followed by the integers:";
	cin >> i;
	cin >> largest;
	cin >> secondLargest;

	if (secondLargest > largest)			//原定的第一大比第二大小 要調換
	{
		temp = secondLargest;
		secondLargest = largest;
		largest = temp;
	}
	for (int b; i > 2; i--)				//在之前拿了largest和secondLargest的數，故i>2，數長度
	{
		cin >> b;

		if (b > largest)				//考慮b大過largest的數
		{
			secondLargest = largest;
			largest = b;
			b = 0;
		}
		if (b > secondLargest)			//考慮b 在largest 和secondLargest中間的數
			secondLargest = b;
	}
	cout << "Largest is " << largest << endl << "Second largest is " << secondLargest << endl;

	system("pause");
	
}