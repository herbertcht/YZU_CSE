// UVa Online Judge: 11332
#include <iostream>
using namespace std;
int main()
{
  int number,temp;
  cout << "Enter a positive integer: ";
  while ( cin >> number)
  {
      if ( number == 0 )
      {
          break;
      }
      while ( number > 9)	//number是否個位數
      {
          temp = number;
          number = 0;		//初始化number

        while (temp)		//temp10的餘數加number，temp沒有再除10時跳出
        {
            number += temp % 10;
            temp /= 10;
        }
      }
    cout << number << endl;
  }
  
  
  
}