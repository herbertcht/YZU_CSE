//perfect number if the sum of its proper factors
#include <iostream>

using namespace std;

int main()
{
	int i,factor,sum,number;
	cout << "Enter a positive integer: ";
	cin >> number;
	cout << "Perfect numbers between 1 and " << number << ":" << endl;
	for( i = 1 ; i <= number ; i++)						//
	{
		sum = 0;
		for ( factor = 1 ; factor <= i / 2 ; factor++ ) //為了讓外循環動起來，所以除2，i是為了數Perfect numbers
			if ( i % factor == 0 )                      //find the factors
				sum += factor;
		if ( sum == i )     							//除了自己，加所有factors的總和等於自己
		{

			cout << sum << " = 1";						//先打印Perfect number
			int a = 2;
			while ( sum > a )							//找出他們的factors
			{
				if ( sum % a == 0)
				cout << " + " << a ;
				a++;
			}
			cout << endl;
			
		}
			
	}
}